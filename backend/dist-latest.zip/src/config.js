module.exports = {
  MONGO_DB: 'mongodb+srv://john:john@cluster0-lom0m.mongodb.net/merng?retryWrites=true&w=majority',
  SECRET_KEY: 'naomi is cool'
}
